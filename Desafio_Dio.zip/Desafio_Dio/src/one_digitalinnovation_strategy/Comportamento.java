package one_digitalinnovation_strategy;

public interface Comportamento {
    void mover();
}
