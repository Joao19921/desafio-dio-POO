package subsistema2.cep;

public class CepApi {
    private static CepApi intancia = new CepApi();

    private CepApi (){

    }
    public static CepApi getIntancia(){
        return intancia;
    }

    public String recuperarCidade(String cep){
        return "Mongagua";
    }

    public String recuperarEstado(String cep){
        return "SP";
    }
}
